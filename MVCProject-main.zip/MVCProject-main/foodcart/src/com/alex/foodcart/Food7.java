package com.alex.foodcart;

public class Food7 {
	private String name;
	private int spice;
	private int price;
	public Food7(String name, int spice, int price) {
		super();
		this.name = name;
		this.spice = spice;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSpice() {
		return spice;
	}
	public void setSpice(int spice) {
		this.spice = spice;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	

}
