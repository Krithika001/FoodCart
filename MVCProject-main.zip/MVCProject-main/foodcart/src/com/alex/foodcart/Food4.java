package com.alex.foodcart;

public class Food4 {
	private String name;
	private int spice;
	private int sweet;
	private int price;
	public Food4(String name, int spice, int sweet, int price) {
		super();
		this.name = name;
		this.spice = spice;
		this.sweet = sweet;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSpice() {
		return spice;
	}
	public void setSpice(int spice) {
		this.spice = spice;
	}
	public int getSweet() {
		return sweet;
	}
	public void setSweet(int sweet) {
		this.sweet = sweet;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}

}
