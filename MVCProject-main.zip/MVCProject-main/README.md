# MVCProject
Demonstrates the application of MVC architecture using JSP servlet and JDBC as a      controller, HTML for the view (User Interface), and MySQL for the databases in the built Web application using Eclipse IDE 2020-12.      Here, The Cloud Kitchen, which is our web browser allows the user to access the menu according to the Entree chosen via the web       servelts.  Next, these web servlets (controllers) communicate to the respective databases through Eclipse and MySQL connection.        Once the data is sent to the controller, it further delivers it to the respective JSP files, which arranges the contents to a display mode, before reaching the user's browser.


![JAVA_PACKAGE_OVERVIEW_19PD05_19PD19](https://user-images.githubusercontent.com/89288089/130311688-89f9758e-7efd-4703-bd4c-4d052ef803e7.png)


Further clarification on : https://youtu.be/ozd9XKId5mY

